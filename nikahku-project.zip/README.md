# NikahKu Studio - Aplikasi Undangan Pernikahan Digital & Portal Pantau Warga

Aplikasi pembuat, pengelola, dan generator undangan pernikahan digital modern, responsif, dan interaktif dengan sistem **Multi-Tenant Komunitas Warga ("Pantau Warga")**:
- **Portal Super Admin Pantau Warga (Kapasitas Tanpa Batas / Unlimited)**: Kelola dan terbitkan akun pengantin gratis untuk warga, persetujuan mandiri (ACC), kirim kredensial login via WhatsApp, serta pantau statistik tamu secara terpusat.
- **Template / Desain Sendiri dari Canva**: Pasang desain undangan yang sudah dibuat di Canva, Photoshop, atau Figma langsung ke dalam web (sebagai poster utama, cover pembuka, atau wallpaper menyeluruh) dengan tetap mempertahankan seluruh fitur interaktif digital (countdown, audio harpa, buku tamu RSVP, QRIS cashless, dan petunjuk arah).
- **Pengaturan Kelola Menu & Bagian Undangan (ON/OFF)**: Calon pengantin bebas memilih bagian mana saja yang ingin ditampilkan atau disembunyikan (Profil Mempelai, Rangkaian Acara, Love Story, Video Prewedding, Galeri Foto, Dresscode, Adab Acara, Amplop Digital, Buku Tamu RSVP, VIP Pass).
- **Mode Terang (Light Mode) High-Contrast & Mode Gelap (Dark Mode)**: Tampilan kontras tinggi yang sangat tajam dan nyaman dibaca tanpa teks pudar di mode terang.
- **5 Pilihan Bahasa Murni & Campuran Estetik**: 🇮🇩 Full Indonesia Murni, ✨ Campuran Estetik Modern (Bilingual Instagram), 🇬🇧 Full English, 🇸🇦 عربي (Arab), dan 🇨🇳 中文 (Cina).
- **Nuansa Agama & Gaya Kalimat Acara**: Pilihan Islam (Akad & QS Ar-Rum 21), Kristen/Katolik (Pemberkatan Kudus & Matius 19:6), Chinese (Teapai & 百年好合), atau Nasional/Universal.
- **Amplop Digital Dual-Mode (Transfer Bank & Scan QRIS E-Wallet)**: Tamu bisa memilih transfer rekening atau memindai barcode QRIS (BCA Mobile, Mandiri, GoPay, OVO, Dana, ShopeePay) lengkap dengan tombol unduh gambar QRIS.
- **RSVP Cepat dengan Template Doa Otomatis**: Tamu bisa mengklik tombol cepat doa (Sakinah Mawaddah, Berkat Kasih Kristus, Happy Wedding, 百年好合, Mubarak) atau mengetik doa kustom sendiri.

---

## 📂 Struktur File

- **[`index.html`](file:///C:/Users/apicm/.gemini/antigravity/scratch/nikah-invitation/index.html)**:
  - **Header & Navbar**:
    - Tombol Switcher Mode: **Mode Terang (Light)** dan **Mode Gelap (Dark)** dengan penyimpanan memori otomatis.
    - Tab Navigasi: *Editor Pengantin*, *Daftar Tamu (RSVP Tracker)*, dan *Pantau Warga (Super Admin)*.
    - Tombol *Login Warga* untuk calon pengantin.
  - **Portal Pantau Warga (Super Admin Hub)**:
    - Banner penjelas kapasitas login warga: **UNLIMITED / Tanpa Batas** dengan isolasi data dan link unik masing-masing.
    - 4 Kartu KPI: Total Pasangan, Total Tamu Warga, Tamu Hadir, dan Tema Terpopuler.
    - Pencarian pengantin & form terbit akun baru (Nama, WA, Email, PIN, Tanggal, Pilihan Tema).
    - Daftar kartu pasangan warga: tombol *Buka Editor*, *Kirim Akses WA*, *Buka Link Tamu*, dan *Hapus*.
  - **Pengaturan Pengantin (Editor)**:
    - **Tab 1: Data Mempelai & Nuansa**: Pilihan nuansa agama (Islam, Kristen, Chinese, Umum), nama lengkap, nama panggilan, orang tua, Instagram, foto prewedding, dan kutipan ayat/mutiara.
    - **Tab 2: Akad & Resepsi**: Tanggal, waktu, nama tempat, alamat, dan link Google Maps.
    - **Tab 3: Media & Musik**: Musik MP3 kustom, YouTube prewedding video, dan galeri foto multi-upload.
    - **Tab 4: Hadiah & Amplop Digital**: Dua rekening bank, alamat pengiriman kado fisik, serta **Mode QRIS (Upload / Link Barcode QRIS & Nama Merchant)**.
    - **Tab 5: Tema, Tipografi & Background**: 18 tema visual, 7 gaya font nyata, 4 bahasa default, video sinematik loop pelaminan, dan kontrol kegelapan overlay.
  - **Daftar Undangan (RSVP Tracker)**: Pantauan status kehadiran ala screenshot mobile, mencakup 4 kartu KPI (Kepala, Hadir, Terundang, Pending), filter kelompok keluarga, filter pengundang (Pria/Wanita), dan generator link WhatsApp otomatis.
  - **Simulator Layar Tamu**: Smartphone simulator di sisi kanan dengan sinkronisasi instan (*Real-Time postMessage Live Sync*).

- **[`invitation.html`](file:///C:/Users/apicm/.gemini/antigravity/scratch/nikah-invitation/invitation.html)**:
  - Halaman undangan digital interaktif untuk para tamu.
  - Mendukung multi-tenant melalui URL parameter `?u={slug}` (misal `?u=budi-siti&to=Pak+RT`).
  - **Living Atmosphere**: Animasi kelopak bunga sakura, serbuk emas, dan kunang-kunang kuning emas yang bernapas (*breathing sine-wave glow*).
  - **Cover Pintu Masuk (*Buka Undangan*)**: Desain dinamis sesuai tema (Bismillah kaligrafi Arab, ornamen `囍` sutra merah Tionghoa, salib katedral Holy Matrimony, atau barcode majalah Vogue).
  - Audio autoplay yang patuh kebijakan browser modern dengan bunyi bel harpa kerajaan sintetis (*Magic Harp Chime* Web Audio API).
  - Letusan confetti bintang emas (*Confetti Burst*) saat membuka undangan.
  - Tombol melayang *"Beri Cinta"* dengan penghitung *live* dan terbangnya hati bercahaya.
  - Kartu tiket VIP hologram & canvas QR Code absensi kehadiran di meja resepsi.
  - **Floating Multi-Language Switcher**: Tombol melayang 4 bahasa (`ID`, `EN`, `عربي`, `中文`).
  - Bagian *Adab Menghadiri Undangan* (etiket pernikahan Islami / syar'i).
  - Timeline perjalanan cinta (*Love Story*), palet warna dresscode, hitung mundur (*countdown*), tombol Google Calendar, peta lokasi.
  - **Amplop Digital Dual-Mode**: Tab *Transfer Bank* dan Tab *Scan QRIS* lengkap dengan tombol simpan gambar QRIS.
  - **Buku Tamu & RSVP Interaktif**: Lengkap dengan 5 chip template ucapan doa sekali klik dan kolom pesan kustom.

---

## 🎨 18 Pilihan Tema Visual Lengkap

### Nuansa Budaya & Khusus
1. **Arabic Islamic Calligraphy**: Kubah mihrab hijau zamrud, kaligrafi Bismillah, bintang dan bulan sabit emas.
2. **Chinese Oriental Blessing**: Sutra merah menyala, karakter kebahagiaan ganda `囍`, awan keberuntungan & emas kaisar.
3. **Holy Matrimony**: Salib katedral sakral, pilar putih marmer, dan lilin altar suci.

### Kelompok Populer
4. **Modern Minimalist**: Clean, netral beige & off-white dengan garis geometris emas tipis.
5. **Rustic Botanical**: Nuansa alam daun eucalyptus, sage green & terracotta hangat.
6. **Luxury Royal Gold**: Kemewahan deep emerald green dan aksen foil emas murni.
7. **Editorial Magazine**: Kontras monokrom elegan ala majalah mode Vogue.
8. **Classic Nusantara**: Sentuhan sakral adat batik & songket tenun berbingkai ukiran emas.

### Kelompok Arsitektur Dunia
9. **Art Deco Gatsby**: Geometri mewah 1920-an, deep navy & yellow gold.
10. **Scandinavian Oak**: Ruang terang, kayu oak natural, dan sentuhan earth tone sejuk.
11. **Industrial Loft**: Tekstur semen beton ekspos, aksen bata terakota & tembaga (*copper*).
12. **Mediterranean Villa**: Dinding stucco hangat, terakota pesisir & aksen daun zaitun.
13. **Japanese Zen**: Minimalis kayu shoji screen, taman batu kerikil & bambu hijau.
14. **Gothic Cathedral**: Nuansa sakral burgundy anggun, lengkungan kubah katedral & tembaga antik.

### Kelompok Artistik & Retro
15. **Pixel Art Retro**: Estetika 8-bit / 16-bit arcade gamer bernostalgia dengan font retro gaming (*Press Start 2P*).
16. **3D Papercut Art**: Seni potongan kertas berlapis dengan bayangan lembut dan warna pastel dreamy.
17. **Risograph Print**: Gaya cetak grafis indie dengan warna neon pop art kontras (fuchsia & cyan).
18. **Stained Glass**: Mosaik kaca patri mewah dengan pembatas timah hitam dan pendar warna permata.

---

## ✍️ 7 Pilihan Tipografi Nyata (True Typography)

1. **👑 Royal Classic**: Kombinasi Playfair Display & Great Vibes.
2. **🌹 Bohemian Romance**: Kombinasi Cormorant Garamond & Pinyon Script yang puitis.
3. **💎 Modern Aesthetic**: Kombinasi Cinzel & Alex Brush yang tegas dan rapi.
4. **📰 Vogue Editorial**: Bodoni Moda & Sans-Serif modern ala editorial majalah fesyen.
5. **🕹️ 8-Bit Pixel**: Press Start 2P & Monospace khas retro video game 90-an.
6. **🕌 Arabic Calligraphy**: Amiri & Naskh font untuk nuansa Arab dan kaligrafi megah.
7. **🧧 Chinese Script**: Ma Shan Zheng & Noto Serif SC untuk tulisan kuas Tionghoa otentik.

---

## 👥 Alur Permintaan Akses & Persetujuan Warga (Request & ACC Approval)

1. **Bagikan Link Pengajuan ke Warga**:
   - Bagikan link formulir pengajuan: `index.html?request=true` (tombol *Salin Link Pengajuan* tersedia di panel *Pantau Warga*).
2. **Warga Mengisi Form & Membuat Password Sendiri**:
   - Calon pengantin memasukkan nama pasangan, no. WhatsApp, email login, **password yang mereka buat sendiri**, dan doa restu untuk admin.
   - Setelah dikirim, status permohonan masuk ke antrean **"Menunggu Persetujuan (ACC)"**.
3. **Admin Menyetujui (ACC) di Portal Pantau Warga**:
   - Admin melihat kartu permohonan lengkap dengan doa yang dikirimkan warga.
   - Klik tombol **"Setujui (ACC)"**.
   - Admin langsung diarahkan untuk mengirim pesan konfirmasi WhatsApp yang berbunyi:
     *"Alhamdulillah, permohonan akses pembuatan Undangan Digital Anda telah DISETUJUI! Silakan login dengan email & password yang telah Anda buat sendiri... Pesan dari Admin: 'Terima kasih atas doanya! Mohon doanya juga ya agar aku segera menyusul bisa sampai ke jenjang yang serius juga... Aamiin 🤲✨'"*
4. **Warga Login & Mengisi Sendiri**:
   - Warga login menggunakan email dan password buatan mereka sendiri.
   - Saat login, muncul sambutan hangat berisi permintaan doa dari admin.
   - Warga bebas menentukan tanggal pernikahan, memilih tema dari 18 katalog, mengatur foto/video pelaminan, mengupload lagu, dan mengelola buku tamu mandiri.

---

## ⚡ Beban Server: Apakah Server Akan Berat Jika Banyak yang Login?

**Jawabannya: TIDAK BERAT SAMA SEKALI (Sangat Ringan & Cepat)!**
- **Arsitektur Client-Side**: Aplikasi ini dirancang menggunakan web teknologi modern berbasis frontend statis (*vanilla JS & CSS*). Semua kalkulasi, penyimpanan data, pemilihan tema, dan animasi kelopak bunga/partikel dijalankan langsung **pada perangkat browser/HP masing-masing pengguna**, bukan di server terpusat.
- **Kapasitas Skalabilitas**: Saat di-hosting di layanan seperti **GitHub Pages, Vercel, Cloudflare, atau Netlify**, file disajikan melalui jaringan CDN global (*Content Delivery Network*). Jika 1.000 atau 10.000 warga membuka dan login secara bersamaan sekalipun, server tetap stabil dengan beban 0% CPU server, tanpa biaya sewa server bulanan.

---

## 🚀 Cara Menjalankan

Cukup klik dua kali atau buka file [`index.html`](file:///C:/Users/apicm/.gemini/antigravity/scratch/nikah-invitation/index.html) langsung di browser (Google Chrome, Edge, Safari, Firefox).
Folder ini juga siap dideploy langsung ke hosting statis gratis mana pun (**GitHub Pages**, **Vercel**, atau **Netlify**).

---

## 🌐 Pengaturan Domain Publik & Cara Publikasi Online (100% Gratis)

Sistem telah dilengkapi dengan **Domain & Share Link Generator**:
- Tautan yang disalin atau dibagikan via WhatsApp otomatis menggunakan nama domain resmi pengantin:
  - Contoh: `https://raditnabila.nikahku.id?to=Bapak+Joko+Widodo`
  - Atau custom domain: `https://radit-nabila.com?to=Bapak+Joko+Widodo`
- Pengantin bebas mengubah nama domain di panel Daftar Undangan atau memilih preset format (`nikahku.id`, `undangan.me`, `.com`, `vercel.app`).
- Tombol salin link otomatis tersedia di setiap kartu tamu (icon copy di samping tombol WhatsApp).

### Cara Mempublikasikan Online Agar Bisa Diakses Semua Tamu Lewat HP:
1. **Vercel / Netlify (Paling Cepat - 1 Menit Jadi)**:
   - Tarik (*drag & drop*) folder project ke [vercel.com](https://vercel.com) atau [netlify.com/drop](https://app.netlify.com/drop).
   - Langsung dapat tautan live gratis: `https://namapasangan.vercel.app`.
2. **GitHub Pages (Gratis Selamanya)**:
   - Buat repo GitHub dan upload berkas HTML.
   - Aktifkan Pages di Settings -> langsung aktif di `https://username.github.io/undangan`.
3. **Domain Pribadi (.com / .id / .my.id)**:
   - Beli domain murah di penyedia domain lokal, lalu hubungkan ke hosting gratis Vercel.
